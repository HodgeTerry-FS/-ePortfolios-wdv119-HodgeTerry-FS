
// global variable
//let score = 1000;

// IFFE?
//(function () {
   // console.log('Program started');

    //will this work
    // sending arguments
  //  console.log(getArea(5,2));


//})();

//function getArea(length, width){
    // area is needed outside of this function
  //  let area = length * width; 
  //  return area;
//}
// (function(){

  //  let make = "kia";
 //   let model = "optima";
 //   let year = "2018";
 //   let mpg = 40;
//
//   let person = {
//        name:"jeff",
  ////      age: 32,
//        ssn: 12345,

   // }
 //   let myCar = createCar("mini","cooper-s",2011);
 //   console.log(myCar.year);
    //console.log(person.age)


//})();


// name parameters  
// function createCar(theMake,theModel,theYear) {
 //   let car = {make:theMake, model:theModel, year:theYear} /// object literal
 //   car.mpg = 100;
 //   return car //now the car is an object

//}

// invoke the fuction
//start();




//(function(){})()


(function()  {
    document.querySelector("#log").addEventListener("click", onclick)
    function onClick(e) {
        let userName = document.querySelector("#uname").value;
        let userPassword = document.querySelector("#pdw").value;
        if (userName == user.name && userpassword == user.password) {
            console.log("Good job"
            )
        } 
        else {
            console.log("Not so Good");
        }

    }
    let user = {name:"Admin" , password: "12345" };
    




})();

