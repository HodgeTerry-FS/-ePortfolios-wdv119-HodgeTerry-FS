Refactor htnl files to male the responsive and add more detail to images 
